## Para hacer:

* **Tarea 1:** Implementar la funcionalidad para abrir configuración/template de sintetizador. **RESUELTO**

* **Tarea 2:** agregar la opción de desactivar el slider por defecto, y no enviar el parámetro si el slider está desactivado, si así puede quedar el valor por defecto en el dispositivo MIDI. **RESUELTO**

* **Tarea 3:** Sí es un bug se dispara en el botón cancel de los alert del load preset. **RESUELTO**

* **Tarea 4:** Porque un status box no limpia completamente al anterior, es un bug? Tengo que destruir de algún modo el objeto o leer la documentación de FL_Box **RESUELTO**

* **Tarea 5:** Después de presionar Save Preset, Reset All o Send All, se pierde la ruta, debería guardar una ruta relativa por defecto y no perderla de donde cargar archhivos. **RESUELTO**

* **Tarea 6:** Pasar todos los botones a menúes? **PENDIENTE** 

* **Tarea 7:** Soporte de idioma. Archivos CSV en un directorio por defecto y a partir de los archivos presentes cargar idiomas soportados en un menú, si no hay idioma, inglés por defecto. **PENDIENTE** 

* **Tarea 8:** Implementar mi propia clase de tests. **PENDIENTE**

* **Tarea 9:** Investigar si puedo obtener la configuración y estados de MIDI CC enviando alguna solicitud MIDI. **PENDIENTE**

* **Tarea 10:** Implementar la capacidad de cargar distintos componentes y no solo sliders desde la configuración, hacerlo polimórficamente. **PENDIENTE**

* **Tarea 11:** Diagrama UML. **PENDIENTE**